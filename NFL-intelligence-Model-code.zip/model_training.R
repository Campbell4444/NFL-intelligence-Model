# ============================================================
# NFL INTELLIGENCE MODEL
# Baseline game model: moneyline, margin/spread, and total
# ============================================================
#
# Uses compact data/games_<season>.rds files created by
# historical_pipeline.R. It builds cross-season pregame ratings
# chronologically so Week 1 is not reduced to identical neutral priors.
#
# Models:
#   - Moneyline: logistic regression
#   - Margin: linear regression
#   - Total: linear regression
#
# No future game is used to build its own features.

MODEL_DIR <- "models"
REPORT_DIR <- "reports"
DATA_DIR <- "data"

dir.create(MODEL_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(REPORT_DIR, showWarnings = FALSE, recursive = TRUE)

model_assert_columns <- function(x, required, object_name = "object") {
  missing_cols <- setdiff(required, names(x))
  if (length(missing_cols) > 0L) {
    stop(
      object_name, " is missing required columns: ",
      paste(missing_cols, collapse = ", "),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

normalize_team_code <- function(x) {
  x <- as.character(x)

  aliases <- c(
    OAK = "LV",
    SD = "LAC",
    STL = "LA",
    LAR = "LA",
    JAC = "JAX",
    WSH = "WAS"
  )

  hit <- x %in% names(aliases)
  x[hit] <- unname(aliases[x[hit]])
  x
}

load_saved_games <- function(
  seasons = NULL,
  data_dir = DATA_DIR,
  regular_and_postseason = TRUE
) {
  files <- list.files(
    data_dir,
    pattern = "^games_[0-9]{4}\\.rds$",
    full.names = TRUE
  )

  if (length(files) == 0L) {
    stop(
      "No data/games_<season>.rds files found. Run process_season() first.",
      call. = FALSE
    )
  }

  file_year <- as.integer(
    sub("^games_([0-9]{4})\\.rds$", "\\1", basename(files))
  )

  if (!is.null(seasons)) {
    seasons <- sort(unique(as.integer(seasons)))
    keep <- file_year %in% seasons
    files <- files[keep]
    file_year <- file_year[keep]
  }

  if (length(files) == 0L) {
    stop("No saved game files match the requested seasons.", call. = FALSE)
  }

  ord <- order(file_year)
  files <- files[ord]

  canonical_cols <- c(
    "game_id", "season", "season_type", "week", "game_date",
    "home_team", "away_team", "home_score", "away_score"
  )

  games_list <- lapply(files, function(path) {
    x <- as.data.frame(readRDS(path))

    required <- c(
      "game_id", "season", "week", "game_date",
      "home_team", "away_team", "home_score", "away_score"
    )
    model_assert_columns(x, required, basename(path))

    if (!"season_type" %in% names(x)) {
      x$season_type <- NA_character_
    }

    x <- x[, canonical_cols, drop = FALSE]
    x
  })

  games <- do.call(rbind, games_list)
  rownames(games) <- NULL

  games$season <- as.integer(games$season)
  games$week <- as.integer(games$week)
  games$game_date <- as.Date(games$game_date)
  games$home_score <- as.numeric(games$home_score)
  games$away_score <- as.numeric(games$away_score)
  games$home_team <- normalize_team_code(games$home_team)
  games$away_team <- normalize_team_code(games$away_team)

  if (regular_and_postseason &&
      "season_type" %in% names(games)) {
    games <- games[
      is.na(games$season_type) |
        games$season_type %in% c("REG", "POST"),
      ,
      drop = FALSE
    ]
  }

  games <- games[
    order(games$season, games$game_date, games$game_id),
    ,
    drop = FALSE
  ]

  if (anyDuplicated(games$game_id) != 0L) {
    stop("Combined saved games contain duplicate game_id values.", call. = FALSE)
  }

  rownames(games) <- NULL
  games
}

expected_elo <- function(rating_a, rating_b) {
  1 / (1 + 10 ^ ((rating_b - rating_a) / 400))
}

regress_to_mean <- function(x, mean_value, keep = 0.67) {
  mean_value + keep * (x - mean_value)
}

build_cross_season_features <- function(
  games,
  elo_k = 20,
  elo_home_advantage = 55,
  offseason_elo_keep = 0.67,
  ewma_alpha = 0.25,
  offseason_form_keep = 0.50,
  league_points_prior = 22,
  league_margin_prior = 0
) {
  required <- c(
    "game_id", "season", "week", "game_date",
    "home_team", "away_team", "home_score", "away_score"
  )
  model_assert_columns(games, required, "games")

  g <- as.data.frame(games)
  g <- g[
    order(g$season, g$game_date, g$game_id),
    ,
    drop = FALSE
  ]
  rownames(g) <- NULL

  teams <- sort(unique(c(g$home_team, g$away_team)))

  elo <- setNames(rep(1500, length(teams)), teams)
  offense <- setNames(rep(league_points_prior, length(teams)), teams)
  defense <- setNames(rep(league_points_prior, length(teams)), teams)
  form_margin <- setNames(rep(league_margin_prior, length(teams)), teams)
  games_seen <- setNames(integer(length(teams)), teams)

  out <- vector("list", nrow(g))
  current_season <- NA_integer_

  for (i in seq_len(nrow(g))) {
    row <- g[i, , drop = FALSE]
    season <- as.integer(row$season)
    home <- as.character(row$home_team)
    away <- as.character(row$away_team)

    if (is.na(current_season) || season != current_season) {
      if (!is.na(current_season)) {
        elo <- regress_to_mean(elo, 1500, offseason_elo_keep)
        offense <- regress_to_mean(
          offense,
          league_points_prior,
          offseason_form_keep
        )
        defense <- regress_to_mean(
          defense,
          league_points_prior,
          offseason_form_keep
        )
        form_margin <- regress_to_mean(
          form_margin,
          league_margin_prior,
          offseason_form_keep
        )
      }
      current_season <- season
    }

    home_elo <- unname(elo[home])
    away_elo <- unname(elo[away])
    home_offense <- unname(offense[home])
    away_offense <- unname(offense[away])
    home_defense <- unname(defense[home])
    away_defense <- unname(defense[away])
    home_margin_form <- unname(form_margin[home])
    away_margin_form <- unname(form_margin[away])

    home_score <- as.numeric(row$home_score)
    away_score <- as.numeric(row$away_score)
    actual_margin <- home_score - away_score
    actual_total <- home_score + away_score
    tie <- as.integer(actual_margin == 0)
    home_win <- ifelse(
      tie == 1L,
      NA_integer_,
      as.integer(actual_margin > 0)
    )

    out[[i]] <- data.frame(
      game_id = as.character(row$game_id),
      season = season,
      season_type = if ("season_type" %in% names(row)) {
        as.character(row$season_type)
      } else {
        NA_character_
      },
      week = as.integer(row$week),
      game_date = as.Date(row$game_date),
      home_team = home,
      away_team = away,
      home_elo = home_elo,
      away_elo = away_elo,
      elo_diff = home_elo - away_elo,
      home_offense = home_offense,
      away_offense = away_offense,
      home_defense = home_defense,
      away_defense = away_defense,
      offense_diff = home_offense - away_offense,
      defense_diff = away_defense - home_defense,
      home_margin_form = home_margin_form,
      away_margin_form = away_margin_form,
      margin_form_diff = home_margin_form - away_margin_form,
      home_games_seen = unname(games_seen[home]),
      away_games_seen = unname(games_seen[away]),
      actual_margin = actual_margin,
      actual_total = actual_total,
      tie = tie,
      home_win = home_win,
      stringsAsFactors = FALSE
    )

    home_result <- if (home_score > away_score) {
      1
    } else if (home_score < away_score) {
      0
    } else {
      0.5
    }

    expected_home <- expected_elo(
      home_elo + elo_home_advantage,
      away_elo
    )

    elo_change <- elo_k * (home_result - expected_home)
    elo[home] <- elo[home] + elo_change
    elo[away] <- elo[away] - elo_change

    offense[home] <- (
      ewma_alpha * home_score +
        (1 - ewma_alpha) * offense[home]
    )
    offense[away] <- (
      ewma_alpha * away_score +
        (1 - ewma_alpha) * offense[away]
    )

    defense[home] <- (
      ewma_alpha * away_score +
        (1 - ewma_alpha) * defense[home]
    )
    defense[away] <- (
      ewma_alpha * home_score +
        (1 - ewma_alpha) * defense[away]
    )

    form_margin[home] <- (
      ewma_alpha * actual_margin +
        (1 - ewma_alpha) * form_margin[home]
    )
    form_margin[away] <- (
      ewma_alpha * (-actual_margin) +
        (1 - ewma_alpha) * form_margin[away]
    )

    games_seen[home] <- games_seen[home] + 1L
    games_seen[away] <- games_seen[away] + 1L
  }

  features <- do.call(rbind, out)
  rownames(features) <- NULL

  attr(features, "final_state") <- list(
    season = current_season,
    elo = elo,
    offense = offense,
    defense = defense,
    form_margin = form_margin,
    games_seen = games_seen,
    params = list(
      elo_k = elo_k,
      elo_home_advantage = elo_home_advantage,
      offseason_elo_keep = offseason_elo_keep,
      ewma_alpha = ewma_alpha,
      offseason_form_keep = offseason_form_keep,
      league_points_prior = league_points_prior,
      league_margin_prior = league_margin_prior
    )
  )

  features
}

prob_clip <- function(p, eps = 1e-6) {
  pmin(pmax(p, eps), 1 - eps)
}

classification_metrics <- function(actual, probability) {
  keep <- !is.na(actual) & is.finite(probability)
  y <- actual[keep]
  p <- prob_clip(probability[keep])

  data.frame(
    n = length(y),
    log_loss = -mean(y * log(p) + (1 - y) * log(1 - p)),
    brier = mean((p - y) ^ 2),
    accuracy = mean((p >= 0.5) == y)
  )
}

regression_metrics <- function(actual, predicted) {
  keep <- is.finite(actual) & is.finite(predicted)
  y <- actual[keep]
  p <- predicted[keep]

  data.frame(
    n = length(y),
    mae = mean(abs(p - y)),
    rmse = sqrt(mean((p - y) ^ 2))
  )
}

fit_models <- function(train) {
  ml_train <- train[!is.na(train$home_win), , drop = FALSE]

  ml <- stats::glm(
    home_win ~ elo_diff + margin_form_diff + offense_diff + defense_diff,
    data = ml_train,
    family = stats::binomial()
  )

  margin <- stats::lm(
    actual_margin ~ elo_diff + margin_form_diff + offense_diff + defense_diff,
    data = train
  )

  total <- stats::lm(
    actual_total ~ home_offense + away_offense + home_defense + away_defense,
    data = train
  )

  list(
    moneyline = ml,
    margin = margin,
    total = total
  )
}

evaluate_models <- function(models, data, label) {
  ml_prob <- as.numeric(
    stats::predict(models$moneyline, newdata = data, type = "response")
  )
  margin_pred <- as.numeric(
    stats::predict(models$margin, newdata = data)
  )
  total_pred <- as.numeric(
    stats::predict(models$total, newdata = data)
  )

  list(
    split = label,
    moneyline = classification_metrics(data$home_win, ml_prob),
    margin = regression_metrics(data$actual_margin, margin_pred),
    total = regression_metrics(data$actual_total, total_pred)
  )
}

train_nfl_model <- function(
  seasons = NULL,
  model_path = file.path(MODEL_DIR, "nfl_game_model.rds")
) {
  games <- load_saved_games(seasons = seasons)
  features <- build_cross_season_features(games)
  final_state <- attr(features, "final_state")

  available_seasons <- sort(unique(features$season))

  if (length(available_seasons) < 3L) {
    stop(
      "At least 3 historical seasons are required for train/validation/test.",
      call. = FALSE
    )
  }

  test_season <- max(available_seasons)
  validation_season <- max(available_seasons[available_seasons < test_season])

  train <- features[
    features$season < validation_season,
    ,
    drop = FALSE
  ]
  validation <- features[
    features$season == validation_season,
    ,
    drop = FALSE
  ]
  test <- features[
    features$season == test_season,
    ,
    drop = FALSE
  ]

  if (nrow(train) == 0L || nrow(validation) == 0L || nrow(test) == 0L) {
    stop("Chronological train/validation/test split failed.", call. = FALSE)
  }

  development_models <- fit_models(train)
  validation_metrics <- evaluate_models(
    development_models,
    validation,
    paste0("validation_", validation_season)
  )

  train_plus_validation <- features[
    features$season <= validation_season,
    ,
    drop = FALSE
  ]
  test_models <- fit_models(train_plus_validation)
  test_metrics <- evaluate_models(
    test_models,
    test,
    paste0("test_", test_season)
  )

  # Final production models use every completed historical game.
  production_models <- fit_models(features)

  bundle <- list(
    models = production_models,
    validation_metrics = validation_metrics,
    test_metrics = test_metrics,
    feature_state = final_state,
    feature_columns = c(
      "elo_diff", "margin_form_diff", "offense_diff", "defense_diff",
      "home_offense", "away_offense", "home_defense", "away_defense"
    ),
    seasons = available_seasons,
    validation_season = validation_season,
    test_season = test_season,
    trained_at = Sys.time()
  )

  saveRDS(bundle, model_path)

  metric_row <- function(split, market, metrics) {
    out <- data.frame(
      split = split,
      market = market,
      n = metrics$n,
      log_loss = NA_real_,
      brier = NA_real_,
      accuracy = NA_real_,
      mae = NA_real_,
      rmse = NA_real_,
      stringsAsFactors = FALSE
    )

    for (nm in intersect(names(metrics), names(out))) {
      out[[nm]] <- metrics[[nm]]
    }

    out
  }

  report <- rbind(
    metric_row(
      validation_metrics$split,
      "moneyline",
      validation_metrics$moneyline
    ),
    metric_row(
      validation_metrics$split,
      "margin",
      validation_metrics$margin
    ),
    metric_row(
      validation_metrics$split,
      "total",
      validation_metrics$total
    ),
    metric_row(
      test_metrics$split,
      "moneyline",
      test_metrics$moneyline
    ),
    metric_row(
      test_metrics$split,
      "margin",
      test_metrics$margin
    ),
    metric_row(
      test_metrics$split,
      "total",
      test_metrics$total
    )
  )

  report_path <- file.path(REPORT_DIR, "model_backtest.csv")
  utils::write.csv(report, report_path, row.names = FALSE)

  message("Saved model to ", model_path)
  message("Saved backtest report to ", report_path)

  print(report)

  invisible(bundle)
}

prepare_future_features <- function(
  matchups,
  model_bundle,
  target_season
) {
  required <- c("home_team", "away_team")
  model_assert_columns(matchups, required, "future matchup data")

  state <- model_bundle$feature_state
  params <- state$params

  elo <- state$elo
  offense <- state$offense
  defense <- state$defense
  form_margin <- state$form_margin

  if (as.integer(target_season) > as.integer(state$season)) {
    seasons_forward <- as.integer(target_season) - as.integer(state$season)

    for (j in seq_len(seasons_forward)) {
      elo <- regress_to_mean(elo, 1500, params$offseason_elo_keep)
      offense <- regress_to_mean(
        offense,
        params$league_points_prior,
        params$offseason_form_keep
      )
      defense <- regress_to_mean(
        defense,
        params$league_points_prior,
        params$offseason_form_keep
      )
      form_margin <- regress_to_mean(
        form_margin,
        params$league_margin_prior,
        params$offseason_form_keep
      )
    }
  }

  result <- as.data.frame(matchups)
  result$home_team <- normalize_team_code(result$home_team)
  result$away_team <- normalize_team_code(result$away_team)

  unknown <- setdiff(
    unique(c(result$home_team, result$away_team)),
    names(elo)
  )

  if (length(unknown) > 0L) {
    stop(
      "Unknown team abbreviation(s): ",
      paste(unknown, collapse = ", "),
      call. = FALSE
    )
  }

  result$home_elo <- unname(elo[result$home_team])
  result$away_elo <- unname(elo[result$away_team])
  result$elo_diff <- result$home_elo - result$away_elo

  result$home_offense <- unname(offense[result$home_team])
  result$away_offense <- unname(offense[result$away_team])
  result$home_defense <- unname(defense[result$home_team])
  result$away_defense <- unname(defense[result$away_team])

  result$offense_diff <- (
    result$home_offense - result$away_offense
  )

  # Positive means the home defense has allowed fewer points.
  result$defense_diff <- (
    result$away_defense - result$home_defense
  )

  result$home_margin_form <- unname(form_margin[result$home_team])
  result$away_margin_form <- unname(form_margin[result$away_team])
  result$margin_form_diff <- (
    result$home_margin_form - result$away_margin_form
  )

  result
}

predict_matchups <- function(
  matchups,
  model_bundle = readRDS(file.path(MODEL_DIR, "nfl_game_model.rds")),
  target_season
) {
  x <- prepare_future_features(
    matchups = matchups,
    model_bundle = model_bundle,
    target_season = target_season
  )

  x$home_win_probability <- as.numeric(
    stats::predict(
      model_bundle$models$moneyline,
      newdata = x,
      type = "response"
    )
  )

  x$away_win_probability <- 1 - x$home_win_probability

  x$projected_home_margin <- as.numeric(
    stats::predict(
      model_bundle$models$margin,
      newdata = x
    )
  )

  x$projected_total <- as.numeric(
    stats::predict(
      model_bundle$models$total,
      newdata = x
    )
  )

  x
}

american_to_implied <- function(odds) {
  odds <- as.numeric(odds)
  ifelse(
    odds > 0,
    100 / (odds + 100),
    abs(odds) / (abs(odds) + 100)
  )
}

american_profit_per_unit <- function(odds) {
  odds <- as.numeric(odds)
  ifelse(
    odds > 0,
    odds / 100,
    100 / abs(odds)
  )
}

bet_ev_per_unit <- function(probability, american_odds) {
  probability <- as.numeric(probability)
  profit <- american_profit_per_unit(american_odds)
  probability * profit - (1 - probability)
}

message("NFL model-training functions loaded successfully.")
