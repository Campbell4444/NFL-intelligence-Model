# ============================================================
# NFL INTELLIGENCE MODEL
# One-command build after the source files are in the project.
# ============================================================

source("historical_pipeline.R")
source("model_training.R")

# Rebuild 2025 training data from the compact file already saved.
if (file.exists("data/games_2025.rds")) {
  process_saved_games(2025)
  validate_training_file("data/processed/training_2025.rds")
}

# Historical seasons are processed one at a time to stay under Posit memory.
# This skips seasons whose compact game files already exist.
target_seasons <- 2015:2025

for (season in target_seasons) {
  games_file <- file.path("data", paste0("games_", season, ".rds"))
  if (!file.exists(games_file)) {
    process_season(season)
  } else {
    message("Already have ", games_file, " - skipping PBP reload.")
  }
  invisible(gc())
}

# Train and backtest. 2024 becomes validation and 2025 becomes test
# when 2015:2025 is available.
model <- train_nfl_model(seasons = target_seasons)

message("PROJECT BUILD COMPLETE")
