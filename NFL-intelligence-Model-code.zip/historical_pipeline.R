# ============================================================
# NFL INTELLIGENCE MODEL
# Historical training-data pipeline
# ============================================================
# Defines functions only. It never auto-runs and never sources itself.
# Uses explicit column access so nflverse tibble/data.table class mixing
# cannot trigger the previous `object 'home_team' not found` error.

DATA_DIR <- "data"
PROCESSED_DIR <- file.path(DATA_DIR, "processed")
MODEL_DIR <- "models"
REPORT_DIR <- "reports"

dir.create(DATA_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(PROCESSED_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(MODEL_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(REPORT_DIR, showWarnings = FALSE, recursive = TRUE)

assert_columns <- function(x, required, object_name = "object") {
  missing_cols <- setdiff(required, names(x))
  if (length(missing_cols) > 0L) {
    stop(
      object_name, " is missing required columns: ",
      paste(missing_cols, collapse = ", "),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

lag_cumsum <- function(x) {
  if (length(x) == 0L) return(numeric(0))
  if (length(x) == 1L) return(0)
  c(0, head(cumsum(x), -1L))
}

load_season <- function(season) {
  if (!requireNamespace("nflfastR", quietly = TRUE)) {
    stop("Package 'nflfastR' is required.", call. = FALSE)
  }

  season <- as.integer(season)
  if (length(season) != 1L || is.na(season)) {
    stop("season must be one valid season year.", call. = FALSE)
  }

  message("Loading season ", season, "...")
  pbp <- nflfastR::load_pbp(season)

  if (is.null(pbp) || nrow(pbp) == 0L) {
    stop("No PBP rows returned for season ", season, ".", call. = FALSE)
  }

  message("Loaded ", format(nrow(pbp), big.mark = ","), " plays.")
  pbp
}

build_game_results <- function(pbp) {
  required <- c(
    "game_id", "season", "week", "game_date",
    "home_team", "away_team", "home_score", "away_score"
  )
  assert_columns(pbp, required, "play-by-play data")

  keep <- required
  if ("season_type" %in% names(pbp)) {
    keep <- c(
      "game_id", "season", "season_type", "week", "game_date",
      "home_team", "away_team", "home_score", "away_score"
    )
  }

  # Pull only the required columns. This avoids both data.table NSE
  # and copying the full ~372-column PBP object.
  games <- as.data.frame(
    setNames(lapply(keep, function(nm) pbp[[nm]]), keep),
    stringsAsFactors = FALSE
  )

  games <- games[
    !is.na(games$game_id) &
      !is.na(games$home_team) &
      !is.na(games$away_team) &
      !is.na(games$home_score) &
      !is.na(games$away_score),
    ,
    drop = FALSE
  ]

  games <- unique(games)

  if (nrow(games) == 0L) {
    stop("No completed games found.", call. = FALSE)
  }

  if (anyDuplicated(games$game_id) != 0L) {
    bad <- unique(games$game_id[duplicated(games$game_id)])
    stop(
      "Multiple distinct game rows found for game_id(s): ",
      paste(utils::head(bad, 5L), collapse = ", "),
      call. = FALSE
    )
  }

  games$season <- as.integer(games$season)
  games$week <- as.integer(games$week)
  games$game_date <- as.Date(games$game_date)
  games$home_score <- as.numeric(games$home_score)
  games$away_score <- as.numeric(games$away_score)

  games$margin <- games$home_score - games$away_score
  games$tie <- as.integer(games$margin == 0)
  games$home_win <- ifelse(
    games$tie == 1L,
    NA_integer_,
    as.integer(games$margin > 0)
  )
  games$total_points <- games$home_score + games$away_score

  games <- games[
    order(games$season, games$game_date, games$game_id),
    ,
    drop = FALSE
  ]

  rownames(games) <- NULL
  games
}

build_team_games <- function(games) {
  required <- c(
    "game_id", "season", "week", "game_date",
    "home_team", "away_team", "home_score", "away_score"
  )
  assert_columns(games, required, "game results")

  season_type <- if ("season_type" %in% names(games)) {
    as.character(games$season_type)
  } else {
    rep(NA_character_, nrow(games))
  }

  home_win_value <- ifelse(
    games$home_score > games$away_score, 1,
    ifelse(games$home_score < games$away_score, 0, 0.5)
  )

  home <- data.frame(
    game_id = as.character(games$game_id),
    season = as.integer(games$season),
    season_type = season_type,
    week = as.integer(games$week),
    game_date = as.Date(games$game_date),
    team = as.character(games$home_team),
    opponent = as.character(games$away_team),
    home = 1L,
    points_for = as.numeric(games$home_score),
    points_against = as.numeric(games$away_score),
    margin = as.numeric(games$home_score - games$away_score),
    win_value = as.numeric(home_win_value),
    stringsAsFactors = FALSE
  )

  away <- data.frame(
    game_id = as.character(games$game_id),
    season = as.integer(games$season),
    season_type = season_type,
    week = as.integer(games$week),
    game_date = as.Date(games$game_date),
    team = as.character(games$away_team),
    opponent = as.character(games$home_team),
    home = 0L,
    points_for = as.numeric(games$away_score),
    points_against = as.numeric(games$home_score),
    margin = as.numeric(games$away_score - games$home_score),
    win_value = as.numeric(1 - home_win_value),
    stringsAsFactors = FALSE
  )

  team_games <- rbind(home, away)

  if (nrow(team_games) != 2L * nrow(games)) {
    stop("Expected exactly two team rows per game.", call. = FALSE)
  }

  team_games <- team_games[
    order(
      team_games$season,
      team_games$team,
      team_games$game_date,
      team_games$game_id
    ),
    ,
    drop = FALSE
  ]

  rownames(team_games) <- NULL
  team_games
}

add_pregame_features <- function(team_games) {
  required <- c(
    "game_id", "season", "game_date", "team", "win_value",
    "points_for", "points_against", "margin"
  )
  assert_columns(team_games, required, "team-game data")

  tg <- as.data.frame(team_games)
  tg <- tg[
    order(tg$season, tg$team, tg$game_date, tg$game_id),
    ,
    drop = FALSE
  ]
  rownames(tg) <- NULL

  n <- nrow(tg)
  tg$games_played <- integer(n)
  tg$prior_wins <- numeric(n)
  tg$prior_points_for <- numeric(n)
  tg$prior_points_against <- numeric(n)
  tg$prior_margin_total <- numeric(n)

  groups <- split(
    seq_len(n),
    interaction(tg$season, tg$team, drop = TRUE, lex.order = TRUE)
  )

  for (idx in groups) {
    tg$games_played[idx] <- seq_along(idx) - 1L
    tg$prior_wins[idx] <- lag_cumsum(tg$win_value[idx])
    tg$prior_points_for[idx] <- lag_cumsum(tg$points_for[idx])
    tg$prior_points_against[idx] <- lag_cumsum(tg$points_against[idx])
    tg$prior_margin_total[idx] <- lag_cumsum(tg$margin[idx])
  }

  played <- tg$games_played > 0L

  tg$win_rate <- 0.5
  tg$avg_points_for <- 22
  tg$avg_points_against <- 22
  tg$avg_margin <- 0

  tg$win_rate[played] <- tg$prior_wins[played] / tg$games_played[played]
  tg$avg_points_for[played] <- (
    tg$prior_points_for[played] / tg$games_played[played]
  )
  tg$avg_points_against[played] <- (
    tg$prior_points_against[played] / tg$games_played[played]
  )
  tg$avg_margin[played] <- (
    tg$prior_margin_total[played] / tg$games_played[played]
  )

  feature_matrix <- as.matrix(
    tg[, c("win_rate", "avg_points_for", "avg_points_against", "avg_margin"),
       drop = FALSE]
  )

  if (any(!is.finite(feature_matrix))) {
    stop("Non-finite pregame feature values produced.", call. = FALSE)
  }

  tg
}

build_training_rows <- function(team_games) {
  required <- c(
    "game_id", "season", "season_type", "week", "game_date",
    "team", "opponent", "home", "points_for", "points_against",
    "games_played", "win_rate", "avg_points_for",
    "avg_points_against", "avg_margin"
  )
  assert_columns(team_games, required, "team-game feature data")

  tg <- as.data.frame(team_games)
  home <- tg[tg$home == 1L, , drop = FALSE]
  away <- tg[tg$home == 0L, , drop = FALSE]

  if (anyDuplicated(home$game_id) != 0L ||
      anyDuplicated(away$game_id) != 0L) {
    stop("Duplicate game_id in team perspective rows.", call. = FALSE)
  }

  h <- data.frame(
    game_id = home$game_id,
    season = home$season,
    season_type = home$season_type,
    week = home$week,
    game_date = home$game_date,
    home_team = home$team,
    away_team = home$opponent,
    home_score = home$points_for,
    away_score = home$points_against,
    home_games_played = home$games_played,
    home_win_rate = home$win_rate,
    home_avg_points_for = home$avg_points_for,
    home_avg_points_against = home$avg_points_against,
    home_avg_margin = home$avg_margin,
    stringsAsFactors = FALSE
  )

  a <- data.frame(
    game_id = away$game_id,
    away_team_check = away$team,
    home_team_check = away$opponent,
    away_games_played = away$games_played,
    away_win_rate = away$win_rate,
    away_avg_points_for = away$avg_points_for,
    away_avg_points_against = away$avg_points_against,
    away_avg_margin = away$avg_margin,
    stringsAsFactors = FALSE
  )

  training <- merge(h, a, by = "game_id", all = FALSE, sort = FALSE)

  if (nrow(training) != nrow(h)) {
    stop("Home/away merge row-count mismatch.", call. = FALSE)
  }

  mismatch <- (
    training$home_team != training$home_team_check |
      training$away_team != training$away_team_check
  )

  if (any(mismatch, na.rm = TRUE)) {
    stop("Home/away team mismatch after merge.", call. = FALSE)
  }

  training$home_team_check <- NULL
  training$away_team_check <- NULL

  training$actual_margin <- training$home_score - training$away_score
  training$tie <- as.integer(training$actual_margin == 0)
  training$home_win <- ifelse(
    training$tie == 1L,
    NA_integer_,
    as.integer(training$actual_margin > 0)
  )
  training$actual_total <- training$home_score + training$away_score

  if (anyDuplicated(training$game_id) != 0L) {
    stop("Training data contains duplicate game_id values.", call. = FALSE)
  }

  training <- training[
    order(training$season, training$game_date, training$game_id),
    ,
    drop = FALSE
  ]

  rownames(training) <- NULL
  training
}

validate_training <- function(training) {
  required <- c(
    "game_id", "season", "week", "game_date", "home_team", "away_team",
    "home_win_rate", "away_win_rate", "home_avg_points_for",
    "away_avg_points_for", "home_avg_points_against",
    "away_avg_points_against", "home_avg_margin", "away_avg_margin",
    "actual_margin", "tie", "home_win", "actual_total"
  )
  assert_columns(training, required, "training data")

  if (nrow(training) == 0L) {
    stop("Training data has zero rows.", call. = FALSE)
  }

  if (anyDuplicated(training$game_id) != 0L) {
    stop("Training data contains duplicate game_id values.", call. = FALSE)
  }

  feature_cols <- c(
    "home_win_rate", "away_win_rate",
    "home_avg_points_for", "away_avg_points_for",
    "home_avg_points_against", "away_avg_points_against",
    "home_avg_margin", "away_avg_margin"
  )

  if (any(!is.finite(as.matrix(training[, feature_cols, drop = FALSE])))) {
    stop("Training data contains non-finite model features.", call. = FALSE)
  }

  if (any(is.na(training$actual_margin)) ||
      any(is.na(training$actual_total))) {
    stop("Training targets contain missing values.", call. = FALSE)
  }

  invisible(TRUE)
}

build_training_from_games <- function(games) {
  team_games <- build_team_games(games)
  team_games <- add_pregame_features(team_games)
  training <- build_training_rows(team_games)
  validate_training(training)

  if (nrow(training) != nrow(games)) {
    stop("Training row count does not equal game row count.", call. = FALSE)
  }

  training
}

process_season <- function(season) {
  season <- as.integer(season)

  pbp <- load_season(season)
  games <- build_game_results(pbp)

  message("Built ", nrow(games), " completed game rows.")

  # Free the very large PBP object immediately after reduction.
  rm(pbp)
  invisible(gc())

  games_file <- file.path(DATA_DIR, paste0("games_", season, ".rds"))
  saveRDS(games, games_file)

  training <- build_training_from_games(games)
  output_file <- file.path(
    PROCESSED_DIR,
    paste0("training_", season, ".rds")
  )
  saveRDS(training, output_file)

  message(
    "Saved ", nrow(training), " training games to ", output_file
  )

  rm(games, training)
  invisible(gc())

  invisible(output_file)
}

process_saved_games <- function(season) {
  season <- as.integer(season)
  games_file <- file.path(DATA_DIR, paste0("games_", season, ".rds"))

  if (!file.exists(games_file)) {
    stop("Saved games file does not exist: ", games_file, call. = FALSE)
  }

  games <- readRDS(games_file)
  training <- build_training_from_games(games)

  output_file <- file.path(
    PROCESSED_DIR,
    paste0("training_", season, ".rds")
  )
  saveRDS(training, output_file)

  message(
    "Saved ", nrow(training), " training games to ", output_file
  )

  invisible(output_file)
}

process_seasons <- function(seasons) {
  seasons <- sort(unique(as.integer(seasons)))

  if (length(seasons) == 0L || any(is.na(seasons))) {
    stop("seasons must contain valid years.", call. = FALSE)
  }

  output_files <- character(length(seasons))

  for (i in seq_along(seasons)) {
    output_files[i] <- process_season(seasons[i])
    invisible(gc())
  }

  names(output_files) <- seasons
  output_files
}

validate_training_file <- function(path) {
  if (!file.exists(path)) {
    stop("Training file does not exist: ", path, call. = FALSE)
  }

  x <- readRDS(path)
  validate_training(x)

  message(
    "Validated ", nrow(x), " rows from season(s): ",
    paste(sort(unique(x$season)), collapse = ", "), "."
  )

  invisible(TRUE)
}

message("Historical pipeline functions loaded successfully.")
